/* This file provides inline versions of floating-pint environment
   handling functions.  If there were any.  */

#ifndef __NO_MATH_INLINES

/* Here is where the code would go.  */

#endif
